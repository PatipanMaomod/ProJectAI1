import asyncio
import websockets
import random
import numpy as np
import math


async def echo(websocket):
    agent_position = []
    target_position = []
    status = []
    first = True


    alpha = 0.02
    gamma = 0.90
    epsilon = 0.2

    state_space = 1000
    action_space = 4  # 4 actions: move forward, move backward, move left, move right
    # สร้าง Q-table
    if first:
        Q = np.zeros((state_space, action_space))

    def update_q(s,a,r,n_s):
        best_next_action = np.argmax(Q[n_s])
        Q[s, a] = Q[s, a] + alpha * (r + gamma * Q[n_s, best_next_action] - Q[s, a])


    def select_action(s):
        if random.uniform(0, 1) < epsilon:
            return random.choice(range(action_space))  # เลือกแบบสุ่ม
        else:
            return np.argmax(Q[s])  # เลือกการกระทำที่มี Q-value สูงสุด

    def step(a):
        re_action = ""
        if a == 0:  # move forward
            re_action = "forward"
        elif a == 1:  # move backward
            re_action = "backward"
        elif a == 2:  # move left
            re_action = "left"
        elif a == 3:  # move right
            re_action = "right"

        return re_action


    def fine_next_state(agent_po,re_action):
        if re_action == "forward":
            agent_po[0] += 1
        elif re_action == "backward":
            agent_po[0] -= 1
        elif re_action == "left":
            agent_po[2] -=1
        elif re_action == "right":
            agent_po[2] += 1

        x = state_index(agent_po)
        return int(x)

    def calculate_distance(p1, p2):
        distance = math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2+ (p1[2] - p2[2]) ** 2)
        return -round(distance, 1)

    def state_index(position):
        return int((abs(position[0] + 10) * 100 + abs(position[1] + 10) * 10 + abs(position[2] + 10)) % 1000)

    try:
        while True:
            message = await websocket.recv()
            if message:
                status = eval(message)
                if status[0] == "Agent":
                    agent_position = [status[1], status[2], status[3]]
                if status[0] == "Target":
                    target_position = [status[1], status[2], status[3]]

                if not first:
                    state = state_index(agent_position)
                    action = select_action(state)
                    reaction = step(action)
                    next_state = fine_next_state(agent_position,reaction)
                    reward = calculate_distance(agent_position, target_position)
                    if calculate_distance(agent_position, target_position) == 0:
                        reward =100
                        epsilon = 0.1
                    if calculate_distance(agent_position, target_position) < -9:
                        reward =-100
                        epsilon = 1
                    update_q(state,action,reward,next_state)

                    await websocket.send(reaction)
                else:
                    first = False
    except websockets.ConnectionClosed:
        print("Client disconnected.")


async def main():
    start_server = websockets.serve(echo, "localhost", 8765)
    await start_server
    print("Server started at ws://localhost:8765")

    await asyncio.Future()


asyncio.run(main())
