import asyncio
import websockets
import random

async def echo(websocket):
    global status
    try:
        while True:
            message = await websocket.recv()
            if message:
                status  = catcanfly(message)
                status[0] = random.randrange(-10,10)
                status[1] = random.randrange(-10,10)
                status[2] = random.randrange(0,10)
            await websocket.send(str(status))





    except websockets.ConnectionClosed:
        print("Client disconnected.")

async def main():
    start_server = websockets.serve(echo, "localhost", 8765)
    await start_server
    print("Server started at ws://localhost:8765")

    await asyncio.Future()


def catcanfly(status):
    status = eval(status)
    return status



asyncio.run(main())