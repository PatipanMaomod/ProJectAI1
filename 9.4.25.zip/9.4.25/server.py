import asyncio
import websockets
import random
import numpy as np
import math



async def echo(websocket):
    status_start = True
    state_space = 10000
    action_space = 4  # 4 actions: move forward, move backward, move left, move right


    # สร้าง Q-table
    Q = np.zeros((state_space, action_space))

    # กำหนดพารามิเตอร์การเรียนรู้
    alpha = 0.1  # learning rate
    gamma = 0.1  # discount factor
    epsilon = 0.3  # exploration factor

    # ฟังก์ชันในการเลือกการกระทำ
    def select_action(state):
        if random.uniform(0, 1) < epsilon:
            return random.choice(range(action_space))  # เลือกแบบสุ่ม
        else:
            return np.argmax(Q[state])  # เลือกการกระทำที่มี Q-value สูงสุด

    # ฟังก์ชันในการอัปเดต Q-table
    def update_Q(state, action, reward, next_state):
        best_next_action = np.argmax(Q[next_state])
        Q[state, action] = Q[state, action] + alpha * (reward + gamma * Q[next_state, best_next_action] - Q[state, action])

    # ฟังก์ชันการคำนวณระยะทางระหว่างกล่องและจุดเป้าหมาย
    def calculate_distance(agent_position, target_position):
        #/(x2-x1)^2+
        return math.sqrt((agent_position[0] - target_position[0]) ** 2 +(agent_position[1] - target_position[1]) ** 2 +(agent_position[2] - target_position[2]) ** 2)

    # ฟังก์ชันในการ reset สภาพแวดล้อม (สำหรับฝึก)
    def reset_environment():
        return random.randint(0, state_space - 1)  # สมมุติว่า agent จะเริ่มต้นที่ตำแหน่งสุ่ม

    # ฟังก์ชันในการจำลองการกระทำ (step)
    def step(action, agent_position):
        # ใช้ action ที่เลือกเพื่อจำลองการเคลื่อนที่
        # (ตัวอย่างการเคลื่อนที่ในแกน X, Y, Z)
        action_list = [0,0,0,0]
        if action == 0:  # move forward
            action_list[0] = 1
        elif action == 1:  # move backward
            action_list[1] = 1
        elif action == 2:  # move left
            action_list[2] = 1
        elif action == 3:  # move right
            action_list[3] = 1

        reward = -calculate_distance(agent_position, target_position)

        return  reward , action_list

    try:
        while True:
            message = await websocket.recv()
            if message:

                if message == "Agent:Complete":
                    Q = np.zeros((state_space, action_space))
                    agent_position = [0, 0, 0]
                    target_position = [0, 0, 0]
                    print('Agent Complete!')
                else:
                    status = eval(message)
                    if status[0] == "Agent":
                        agent_position = [status[1], status[2], status[3]]

                    if status[0] == "Target":
                        target_position = [status[1], status[2], status[3]]


                    if status_start:
                        agent_position = [0,0,0]
                        target_position= [0,0,0]
                        status_start = False
                    # คำนวณระยะห่างจากจุดเป้าหมายเพื่อเป็น reward
                    state = reset_environment()  # รีเซ็ตสภาพแวดล้อม
                    action = select_action(state)  # เลือกการกระทำ
                    reward , action_list = step(action, agent_position)  # ส่ง action ไปยังสภาพแวดล้อม

                    update_Q(state, action, reward, state)  # อัปเดต Q-table

                    agent_position_str = str(action_list)  # แปลงตำแหน่งของ agent เป็น string
                    await websocket.send(agent_position_str)  # ส่งแค่ตำแหน่งของ agent กลับไป


    except websockets.ConnectionClosed:
        print("Client disconnected.")


async def main():
    start_server = websockets.serve(echo, "localhost", 8765)
    await start_server
    print("Server started at ws://localhost:8765")

    await asyncio.Future()


asyncio.run(main())
